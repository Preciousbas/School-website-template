# bootstrap-4-calendar
A nicely designed bootstrap 4 calendar template.

Use `Live Server` to run the demo project locally. 

Or visit the sandbox https://88lvfm.csb.app/ online.

![screenshot](https://github.com/ylli2000/bootstrap-4-calendar/blob/master/screenshot.PNG "screenshot")
